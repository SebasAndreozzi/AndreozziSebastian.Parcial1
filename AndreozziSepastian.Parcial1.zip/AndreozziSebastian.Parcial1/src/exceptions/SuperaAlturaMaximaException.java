/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exceptions;

/**
 *
 * @author sebas
 */
public class SuperaAlturaMaximaException extends RuntimeException{
    private static final String MENSAJE = "La altura ingresada supera la altura maxima";
    
     public SuperaAlturaMaximaException(){
        super(MENSAJE);
    }
    
    public SuperaAlturaMaximaException(String mensaje) {
        super(mensaje);
    }
}