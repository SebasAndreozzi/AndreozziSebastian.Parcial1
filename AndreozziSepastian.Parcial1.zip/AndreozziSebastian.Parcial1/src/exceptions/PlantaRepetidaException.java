/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exceptions;

/**
 *
 * @author sebas
 */
public class PlantaRepetidaException extends RuntimeException{
    private static final String MENSAJE = "Ya se ha ingresado esta planta anteriormente";
    
     public PlantaRepetidaException(){
        super(MENSAJE);
    }
}
