/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import exceptions.PlantaRepetidaException;
import interfaces.Podable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author sebas
 */
public class GestorDePlantas {
    private List<Planta> plantas;
    
    public GestorDePlantas(){
        plantas = new ArrayList<>();
        
    }
    
    public void agregarPlanta(Planta planta){
        if(planta != null){
            validarPlanta(planta);
            plantas.add(planta);
        }
        
    }
    
    private void validarPlanta(Planta planta){
        if(!plantas.isEmpty()){
            for(Planta p : plantas){
                if(p.equals(planta)){
                    throw new PlantaRepetidaException();
                }
            }
        }
    }
            
    public void mostrarPlantas(){
        if (!plantas.isEmpty()){
            for(Planta p : plantas){
                System.out.println(p);
            }
        }
    }

    public void podarPlantas(){
        if(!plantas.isEmpty()){
            for(Planta p : plantas){
                if(p instanceof Podable pp){
                    pp.podar();
                }
                else{
                    System.out.println("La planta:\n" + p.toString() + "\nNo se requiere poda");
                }
            }
        }
    }
    
    public ArrayList<Flor> filtrarPorTemporadaFlorecimiento(Temporada temporada){
        ArrayList<Flor> floresPorTemporada = new ArrayList<>();
        
        if(!plantas.isEmpty()){
            for(Planta p : plantas){
                if(p instanceof Flor f){
                    if(f.getTemporadaFlorecimiento().equals(temporada)){
                        System.out.println(p);
                        floresPorTemporada.add(f);
                    }
                }
            }
        }
        
        if(floresPorTemporada.isEmpty()){
            System.out.println("No hay plantas que florescan en esa temporada");
            return floresPorTemporada;
        }
        
        return floresPorTemporada;
    }
        
}
