/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import interfaces.Aromatica;

/**
 *
 * @author sebas
 */
public class Flor extends Planta implements Aromatica{

    private Temporada temporadaFlorecimiento;

    public Flor(String nombre, String climaProspero, String ubicacionJardin, Temporada temporadaFlorecimiento){
        super(nombre, climaProspero, ubicacionJardin);
        this.temporadaFlorecimiento = temporadaFlorecimiento;
    }
    
    public Temporada getTemporadaFlorecimiento(){
        return temporadaFlorecimiento;
    }

    @Override
    public void desprenderOlor() {
        System.out.println("Soy una flor y desprendo aroma");
    }
    
    @Override
    public String toString(){
        return super.toString() + "\nTemporada florecimiento: " + temporadaFlorecimiento;
    }
}
