/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Objects;

/**
 *
 * @author sebas
 */
public abstract class Planta {
    private String nombre;
    private String climaProspero;
    private String ubicacionJardin;


    public Planta(String nombre, String climaProspero, String ubicacionJardin){
        this.nombre = nombre;
        this.climaProspero = climaProspero;
        this.ubicacionJardin = ubicacionJardin;
        
    }
    
    @Override
    public boolean equals(Object o){
        if(o == null || !(o instanceof Planta p)){
            return false;
        }
        return this.nombre.equals(p.nombre) && this.ubicacionJardin.equals(p.ubicacionJardin);
    }
    
    @Override
    public int hashCode(){
        return Objects.hash(nombre, ubicacionJardin);
    }
    
    @Override
    public String toString(){
        return "Nombre: " + nombre +"\n"+ "Clima prospero: " + climaProspero +"\n"+ "Ubicaion: " + ubicacionJardin;
    }
}
