/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import exceptions.SuperaAlturaMaximaException;
import interfaces.Aromatica;
import interfaces.Podable;

/**
 *
 * @author sebas
 */
public class Arbol extends Planta implements Podable, Aromatica{
    private static final double MAX_ALTURA = 15.0;
    
    private double altura;
    
    public Arbol(String nombre, String climaProspero, String ubicacionJardin, double altura){
        super(nombre, climaProspero, ubicacionJardin);
        if (altura > MAX_ALTURA){
            throw new SuperaAlturaMaximaException("La altura ingressada supera " + MAX_ALTURA);
        }
        this.altura = altura;
        
    }
    
    @Override
    public void podar(){
        System.out.println("Arbol podado");
    }
    
    @Override
    public void desprenderOlor() {
        System.out.println("Soy un arbol y desprendo olor");
    }
    
    @Override
    public String toString(){
        return super.toString() +"\nAltura (m):"+ altura;
    }
}
