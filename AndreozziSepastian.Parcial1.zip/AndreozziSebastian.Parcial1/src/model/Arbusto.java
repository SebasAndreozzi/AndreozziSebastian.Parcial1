/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import exceptions.DensidadFueraDeRangoException;
import interfaces.Podable;

/**
 *
 * @author sebas
 */
public class Arbusto extends Planta implements Podable{
    private static final int MAX_DENSIDAD_FOLLAJE = 10;
    private static final int MIN_DENSIDAD_FOLLAJE = 1;

    private int densidadFollaje;

    public Arbusto(String nombre, String climaProspero, String ubicacionJardin, int densidadFollaje){
        super(nombre, climaProspero, ubicacionJardin);
        
        if(densidadFollaje > 10){
            throw new DensidadFueraDeRangoException("Densidad ingresada mayor a " + MAX_DENSIDAD_FOLLAJE);
        }
        if(densidadFollaje < 1){
            throw new DensidadFueraDeRangoException("Densidad ingresada menor a " + MIN_DENSIDAD_FOLLAJE);
        }
        
        this.densidadFollaje = densidadFollaje;
    }

    @Override
    public void podar() {
        System.out.println("Arbusto podado");
    }
    
    @Override
    public String toString(){
        return super.toString() + "\nDensidad: " + densidadFollaje;
    }
}
