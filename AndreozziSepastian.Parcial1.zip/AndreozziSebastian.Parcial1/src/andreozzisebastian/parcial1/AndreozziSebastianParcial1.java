package andreozzisebastian.parcial1;

import java.util.ArrayList;
import model.Arbol;
import model.Arbusto;
import model.Flor;
import model.GestorDePlantas;
import model.Temporada;


public class AndreozziSebastianParcial1 {

    public static void main(String[] args) {
        GestorDePlantas g1 = new GestorDePlantas();
        
        Arbol a1 = new Arbol("Roble", "Templado", "Norte", 10.3);
        Arbol a2 = new Arbol("Roble", "Templado", "Sur", 10.3);
        Arbusto aa1 = new Arbusto("Arandano", "Templado", "Este", 10);
        Flor f1 = new Flor("Margarita", "Frio", "Oeste", Temporada.INVIERNO);
        
        g1.agregarPlanta(a1);
        g1.agregarPlanta(a2);
        g1.agregarPlanta(aa1);
        g1.agregarPlanta(f1);
        
        g1.mostrarPlantas();
        g1.podarPlantas();
        ArrayList<Flor> ft = g1.filtrarPorTemporadaFlorecimiento(Temporada.INVIERNO);
        System.out.println(ft);
        
        //g1.agregarPlanta(a1);
        //Arbol a3 = new Arbol("Abedul", "Templado", "Norte", 17.3);
        //Arbusto aa2 = new Arbusto("aa2", "Templado", "Este", 20);
        //Arbusto aa3 = new Arbusto("aa3", "Templado", "Este", 0);
        
    }
    
}
